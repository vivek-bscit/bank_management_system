﻿namespace bank32020
{
    internal class sqlConnection
    {
        private string v;

        public sqlConnection(string v)
        {
            this.v = v;
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }

        internal void Close()
        {
            throw new NotImplementedException();
        }
    }
}