﻿namespace bank32020
{
    partial class AddAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddAccount));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.AcNameTb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AcPhoneTb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AcAddressTb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.OccupationTb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.IncomeTb = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Gencb = new System.Windows.Forms.ComboBox();
            this.Educationcb = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.EditBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.AccountDGV = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AccountDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(48, 818);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(474, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(474, 56);
            this.label1.TabIndex = 16;
            this.label1.Text = "New Account Form";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(65, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 37);
            this.label5.TabIndex = 26;
            this.label5.Text = "Name";
            // 
            // AcNameTb
            // 
            this.AcNameTb.Location = new System.Drawing.Point(65, 175);
            this.AcNameTb.Name = "AcNameTb";
            this.AcNameTb.Size = new System.Drawing.Size(258, 27);
            this.AcNameTb.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(453, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 37);
            this.label2.TabIndex = 28;
            this.label2.Text = "Phone";
            // 
            // AcPhoneTb
            // 
            this.AcPhoneTb.Location = new System.Drawing.Point(453, 175);
            this.AcPhoneTb.Name = "AcPhoneTb";
            this.AcPhoneTb.Size = new System.Drawing.Size(258, 27);
            this.AcPhoneTb.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(810, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 37);
            this.label3.TabIndex = 30;
            this.label3.Text = "Address";
            // 
            // AcAddressTb
            // 
            this.AcAddressTb.Location = new System.Drawing.Point(810, 175);
            this.AcAddressTb.Multiline = true;
            this.AcAddressTb.Name = "AcAddressTb";
            this.AcAddressTb.Size = new System.Drawing.Size(258, 121);
            this.AcAddressTb.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(1138, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 37);
            this.label4.TabIndex = 32;
            this.label4.Text = "Occupation";
            // 
            // OccupationTb
            // 
            this.OccupationTb.Location = new System.Drawing.Point(1138, 175);
            this.OccupationTb.Name = "OccupationTb";
            this.OccupationTb.Size = new System.Drawing.Size(258, 27);
            this.OccupationTb.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(1138, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 37);
            this.label6.TabIndex = 34;
            this.label6.Text = "Income";
            // 
            // IncomeTb
            // 
            this.IncomeTb.Location = new System.Drawing.Point(1138, 273);
            this.IncomeTb.Name = "IncomeTb";
            this.IncomeTb.Size = new System.Drawing.Size(258, 27);
            this.IncomeTb.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(453, 222);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 37);
            this.label7.TabIndex = 35;
            this.label7.Text = "Gender";
            // 
            // Gencb
            // 
            this.Gencb.FormattingEnabled = true;
            this.Gencb.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Gencb.Location = new System.Drawing.Point(453, 273);
            this.Gencb.Name = "Gencb";
            this.Gencb.Size = new System.Drawing.Size(258, 28);
            this.Gencb.TabIndex = 36;
            // 
            // Educationcb
            // 
            this.Educationcb.FormattingEnabled = true;
            this.Educationcb.Items.AddRange(new object[] {
            "Uneducated",
            "Diploma",
            "UG",
            "PG",
            "PHD"});
            this.Educationcb.Location = new System.Drawing.Point(65, 273);
            this.Educationcb.Name = "Educationcb";
            this.Educationcb.Size = new System.Drawing.Size(258, 28);
            this.Educationcb.TabIndex = 38;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(65, 222);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(140, 37);
            this.label8.TabIndex = 37;
            this.label8.Text = "Education";
            // 
            // EditBtn
            // 
            this.EditBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.EditBtn.Font = new System.Drawing.Font("Calibri", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EditBtn.Location = new System.Drawing.Point(600, 349);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(234, 56);
            this.EditBtn.TabIndex = 39;
            this.EditBtn.Text = "Edit";
            this.EditBtn.UseVisualStyleBackColor = false;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.CancelBtn.Font = new System.Drawing.Font("Calibri", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CancelBtn.Location = new System.Drawing.Point(1039, 349);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(234, 56);
            this.CancelBtn.TabIndex = 40;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = false;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.SubmitBtn.Font = new System.Drawing.Font("Calibri", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SubmitBtn.Location = new System.Drawing.Point(207, 349);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(234, 56);
            this.SubmitBtn.TabIndex = 41;
            this.SubmitBtn.Text = "Submit";
            this.SubmitBtn.UseVisualStyleBackColor = false;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // AccountDGV
            // 
            this.AccountDGV.BackgroundColor = System.Drawing.Color.White;
            this.AccountDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AccountDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AccountDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AccountDGV.GridColor = System.Drawing.Color.Black;
            this.AccountDGV.Location = new System.Drawing.Point(54, 426);
            this.AccountDGV.Name = "AccountDGV";
            this.AccountDGV.RowHeadersWidth = 51;
            this.AccountDGV.RowTemplate.DividerHeight = 5;
            this.AccountDGV.RowTemplate.Height = 40;
            this.AccountDGV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.AccountDGV.Size = new System.Drawing.Size(1406, 392);
            this.AccountDGV.TabIndex = 42;
            this.AccountDGV.UseWaitCursor = true;
            this.AccountDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AccountDGV_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1422, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // AddAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1457, 818);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.AccountDGV);
            this.Controls.Add(this.SubmitBtn);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.EditBtn);
            this.Controls.Add(this.Educationcb);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Gencb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.IncomeTb);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.OccupationTb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AcAddressTb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AcPhoneTb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AcNameTb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddAccount";
            this.Load += new System.EventHandler(this.AddAccount_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AccountDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label5;
        private TextBox AcNameTb;
        private Label label2;
        private TextBox AcPhoneTb;
        private Label label3;
        private TextBox AcAddressTb;
        private Label label4;
        private TextBox OccupationTb;
        private Label label6;
        private TextBox IncomeTb;
        private Label label7;
        private ComboBox Gencb;
        private ComboBox Educationcb;
        private Label label8;
        private Button EditBtn;
        private Button CancelBtn;
        private Button SubmitBtn;
        private DataGridView AccountDGV;
        private PictureBox pictureBox1;
        private EventHandler cancelBtn_Click;

        public EventHandler label5_Click { get; private set; }
        public EventHandler textBox1_TextChanged { get; private set; }
        public EventHandler label6_Click { get; private set; }
        public EventHandler textBox5_TextChanged { get; private set; }
        public EventHandler pictureBox1_Click { get; private set; }

        public EventHandler GetCancelBtn_Click()
        {
            return cancelBtn_Click;
        }

        private void SetCancelBtn_Click(EventHandler value)
        {
            cancelBtn_Click = value;
        }
    }
}