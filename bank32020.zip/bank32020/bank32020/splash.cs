namespace bank32020
{
    public partial class splash : Form
    {
        public splash()
        {
            InitializeComponent();
        }
    }
}