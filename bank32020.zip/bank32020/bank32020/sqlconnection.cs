﻿namespace bank32020
{
    internal class sqlconnection
    {
    }
}